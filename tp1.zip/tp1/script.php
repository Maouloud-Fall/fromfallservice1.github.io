<?php
$telephonerecu=$_GET['telephone'];
$agerecu=$_GET['age'];
$adressrecu=$_GET['adress'];

echo 'bonjour'<br> 'vous avez saisi les infos:'<br>;
echo 'telephone:',$telephonerecu,<br>;
echo 'age:',$agerecu,<br>;
echo 'adress:',$adressrecu,<br>;
?>
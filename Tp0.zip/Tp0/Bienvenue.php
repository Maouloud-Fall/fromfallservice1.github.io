<?php
//Recuperation des donnees du formulaire
$Loginrecu = $_GET['Login'];
$Passrecu = $_GET['Pass'];
echo 'Bonjour! <br> Vous avez saisi les infos: <br>';
echo 'Login : ', $Loginrecu, '<br>';
echo 'Pass : ', $Passrecu, '<br>';
if($Passrecu !='isepdwm2022@')
echo "Bienvenue $Loginrecu ";  
else
echo "Erreur, mot de passe invalide";
echo '<br><a href="Login.html">Recommencer</a>';
echo '<br><a href="passwd.txt">passwd</a>';
?>
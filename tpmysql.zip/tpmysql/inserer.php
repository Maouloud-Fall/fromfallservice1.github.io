<?php
//Recuperation des donnees du formulaire
$cni = $_POST['cni'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$classe = $_POST['classe'];
$adresse = $_POST['adresse'];
//Connexion au serveur de BD et choix de la base
$conn = mysqli_connect('localhost','root','','base 1');
//Creation de la requete sql pour inserer les donnees
$req= "Insert into apprenants (cni, nom, prenom, classe, adresse) 
values($cni , '".$nom."' , '".$prenom."' , '".$classe."' , '".$adresse."')";
//Execution de la requete
$resultat=mysqli_query($conn, $req) or die(mysqli_error($conn));
if($resultat){
    echo "Insertion reussie ! <br>";
    echo "<a href='affichage.php'>Afficher la liste .</a><br>";
    echo "<a href='form_ajout.html'>Inserer un autre apprenant</a>";
}
?>
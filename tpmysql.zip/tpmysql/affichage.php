<?php
//Connexion au serveur de base de donnees et choix de la base
$conn = mysqli_connect('localhost','root','','base 1');
if (mysqli_connect_error()){
    echo 'Echec connexion <br>';
    echo "Message d'erreur : ", mysqli_connect_error();
}
else{
    echo 'Connexion reussie ! <br>';
    //Requete sql
    $requete= "Select * from apprenants";
    //Execution de la requete sql

    $resultats = mysqli_query($conn, $requete) or die (mysqli_error());

    //Affichage du resultat
    echo "<table border>";
        echo "<tr><th>CNI</th><th>Prenom</th><th>Nom</th><th>Classe</th><th>Adresse</th><th>
        Suppression</th><th>Modification</th></tr>";
        while($ligne = mysqli_fetch_assoc($resultats)){
            echo '<tr>';
                echo "<td>".$ligne['cni']."</td>
                <td>".$ligne['prenom']."</td>
                <td>".$ligne['nom']."</td>
                <td>".$ligne['classe']."</td>
                <td>".$ligne['adresse']."</td>
                <td><a href='supprimer.php?id=".$ligne['cni']."'> Supprimer</a></td>
                <td><a href='modifier.php?id=".$ligne['cni']."'> Modifier</a></td>";
            
            echo '</tr>';
        }
   echo "</table>";

}
?>
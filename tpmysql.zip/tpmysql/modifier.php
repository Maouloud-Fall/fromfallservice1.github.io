<?php
     //Recuperation de cni transmis via l'URL
     $id = $_GET['id'];
     //Connexion au serveur de BD 
    $conn = mysqli_connect('localhost','root','','base 1');
    $req = " select * from apprenants where cni = $id ";         
    
    $resultat=mysqli_query($conn, $req) or die(mysqli_error($conn));
    $ligne = mysqli_fetch_assoc($resultat);

?>
<form action = "form_modi.php" method ="post">
    <input type="hidden" name ="cni"
    value = "<?php echo $ligne ['cni'];?>"><br>
    prenom <input type="text" name ="prenom"
    value = "<?php echo $ligne ['prenom'];?>"><br>
    nom <input type="text" name ="nom"
    value = "<?php echo $ligne ['nom'];?>"><br>
    classe <input type="text" name ="classe"
    value = "<?php echo $ligne ['classe'];?>"><br>
    address <input type="text" name ="adresse"
    value = "<?php echo $ligne ['adresse'];?>"><br>
    <input type="submit" value ="Enregistrer">
    <input type="reset" value ="Annuler">
</form>
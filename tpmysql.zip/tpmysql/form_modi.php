<?php
    //Recuperation des donnees du form
    $cni = $_POST['cni'];
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $classe = $_POST['classe'];
    $adresse = $_POST['adresse'];

    //Connexion a la BD et execution de la requete de mise a jour
    $conn = mysqli_connect('localhost','root','','base 1');
    $requete = "UPDATE apprenants
                SET prenom ='$prenom',
                nom ='$nom',
                classe ='$classe',
                adresse ='$adresse'
                WHERE cni = $cni";
    $resultat=mysqli_query($conn, $requete) or die(mysqli_error($conn));
    
    echo "Modifications effectuees <br>";
    echo "<a href='affichage.php'>Retourner a la liste</a>";


?>
<?php
    echo "Bienvenue sur la page de suppression <br>";

    echo "Vous voulez supprimer "; echo $_GET['id'];
    $id = $_GET['id'];
    //Connexion au serveur de BD 
    $conn = mysqli_connect('localhost','root','','base 1');
    
    //Creation de la requete sql pour supprimer 
    $req ="delete from apprenants where cni=$id";
    
    $resultat=mysqli_query($conn, $req) or die(mysqli_error($conn));
    if($resultat){
        echo "Suppression reussie ! <br>";
        echo "<a href='affichage.php'>Afficher la liste ?</a><br>";
        
    }
    else{
        echo "Echec de la suppression ";
    }

?>
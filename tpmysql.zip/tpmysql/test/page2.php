<?php
    $prenom = $_GET['prenom'];
    $nom = $_GET['nom'];
    echo "Vous avez choisi ce nom : $prenom  $nom <br>";

?>
<a href="page.html">Aller a la page</a>
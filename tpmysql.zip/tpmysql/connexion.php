<?php
//Connexion au serveur de base de donnees
//Parametres: adresse_serveur, Login, mot_de_passe, base_de_donnees
$conn = mysqli_connect('localhost', 'root','','base 1');
//Tester si la connexion a reussi ou pas 
if(mysqli_connect_error()){ //Cas echec
    echo 'Echec connexion <br>';
    echo "Message d'erreur : ", mysqli_connect_error();
}
else{ //cas succes
    echo 'Connexion reussi !';
}
?>
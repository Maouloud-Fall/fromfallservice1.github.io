@extends('layouts.app')

@section("title", "Enregistrement d'un étudiant")

@section("content")
    <div class="row">
        <h3>Enregistrement d'un étudiant</h3>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (Session::has('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
        @endif
        <form enctype="multipart/form-data"
            action="{{ route('students.store') }}" method="post">
            @csrf
            <div class="form-floating mb-3">
              <input
                type="text"
                class="form-control" name="name" id="name" 
                placeholder="Votre nom complet :">
              <label for="name">Votre nom complet :</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" 
                    name="address" id="address"
                    placeholder="Votre adresse : ">
                <label for="address">Votre adresse : </label>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">
                    Votre Image
                </label>
                <input 
                    class="form-control"
                    type="file" name="image" id="image">
            </div>
            <div class="form-floating mb-3">
                <input 
                    class="form-control"
                    placeholder="Votre numéro de téléphone"
                    type="tel" name="phone" id="phone">
                <label for="phone">
                    Votre numéro de téléphone : 
                </label>
            </div>
            <div class="form-floating mb-3">
              <input
                type="email"
                class="form-control" name="email" id="email" 
                placeholder="Votre adresse email : ">
              <label for="email">
                Votre adresse email : 
              </label>
            </div>
            <div class="form-floating mb-3">
                <textarea 
                class="form-control"
                placeholder="Votre biographie : "
                name="bio" id="bio"></textarea>
                <label for="bio">Votre biographie : </label>
            </div>
            <div class="form-check mb-3">
                <input 
                    class="form-check-input"
                    value="true" checked
                    type="checkbox" name="status" id="status">
                <label for="status" class="form-check-label">
                    Statut de l'étudiant
                </label>
            </div>
            <div class="d-grid gap-2 mb-3">
                <button type="submit" class="btn btn-primary">
                    Enregistrer cet étudiant
                </button>
            </div>
        </form>
    </div>
@endsection
Accep mat prompt'Donner un maticule:';
BEGIN
     DELETE emp
     WHERE empno=&mat;
END;
/
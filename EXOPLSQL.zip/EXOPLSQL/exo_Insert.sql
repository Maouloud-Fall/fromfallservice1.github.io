Accep numd Prompt 'DONNEZ UN NUMERO DE DEPARTEMENT:';
Accep nomd prompt 'Donnez un nom de departement:';
Accep locd prompt 'Donnez une localité:';
BEGIN
     insert into dept(deptno, dname,loc)
     values(&numd,'&nomd', '&locd');
END;
/

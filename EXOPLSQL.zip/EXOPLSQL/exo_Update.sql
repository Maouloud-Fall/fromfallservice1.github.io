BEGIN
     Update emp
     Set sal=sal+500;
    ENd;
    /

BEGIN 
    MERGE INTO Service
    USING dept
    ON(dept.deptno=Service.deptno)
    WHEN MATCHED THEN UPDATE
    SET service.dname=dept.dname, service.loc=dept.loc
    WHEN NOT MATCHED THEN INSERT 
    VALUES(dept.deptno,dept.dname,dept.loc);
END;
/
